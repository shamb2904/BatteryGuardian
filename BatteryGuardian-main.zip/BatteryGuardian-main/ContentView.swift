import SwiftUI
import UserNotifications
import AppKit

struct ContentView: View {
    @State private var batteryPercentage: Int = 100
    @State private var isCharging: Bool = false
    @State private var condition: String = "Unknown"
    @State private var lastChecked: String = ""
    @State private var isRefreshing = false
    @State private var notificationSentHigh = false
    @State private var notificationSentLow = false

    var body: some View {
        ZStack {
            Image("BackgroundImage")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
                .blur(radius: 8)

            LinearGradient(
                gradient: Gradient(colors: [Color.black.opacity(0.6), Color.black.opacity(0.3)]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ).ignoresSafeArea()

            VStack(spacing: 28) {
                HStack(spacing: 10) {
                    Image(systemName: "atom")
                        .font(.system(size: 36, weight: .bold))
                        .symbolRenderingMode(.palette)
                        .foregroundStyle(.cyan, .white)
                        .rotationEffect(.degrees(isRefreshing ? 360 : 0))
                        .animation(isRefreshing ? .linear(duration: 1).repeatForever(autoreverses: false) : .default, value: isRefreshing)

                    VStack(alignment: .leading, spacing: 4) {
                        Text("Battery Guardian")
                            .font(.largeTitle.bold())
                            .foregroundColor(.white)

                        Text("Smarter charging. Healthier battery.")
                            .font(.headline)
                            .foregroundColor(.gray)
                    }
                    Spacer()
                }
                .padding(.horizontal)

                Divider().background(.white.opacity(0.3))

                VStack(spacing: 16) {
                    infoCard(icon: "battery.100", label: "Battery", value: "\(batteryPercentage)%")
                    infoCard(icon: isCharging ? "bolt.fill" : "bolt.slash", label: "Charging", value: isCharging ? "Yes" : "No")
                    infoCard(icon: "heart.text.square.fill", label: "Condition", value: condition, color: conditionColor())
                }

                Text("Last checked at \(lastChecked)")
                    .font(.footnote)
                    .foregroundColor(.white.opacity(0.6))

                Button(action: {
                    withAnimation(.easeInOut(duration: 0.5)) {
                        isRefreshing = true
                    }
                    updateBatteryInfo()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        isRefreshing = false
                    }
                }) {
                    HStack(spacing: 8) {
                        Image(systemName: "arrow.clockwise")
                            .rotationEffect(isRefreshing ? .degrees(360) : .degrees(0))
                            .animation(isRefreshing ? .linear(duration: 1).repeatForever(autoreverses: false) : .default, value: isRefreshing)

                        Text("Refresh")
                    }
                    .font(.system(size: 16, weight: .semibold))
                    .padding(.horizontal, 20)
                    .padding(.vertical, 10)
                    .background(
                        Capsule()
                            .fill(.ultraThinMaterial)
                            .shadow(color: .black.opacity(0.3), radius: 8, x: 0, y: 5)
                    )
                }
                .buttonStyle(.plain)
            }
            .padding(30)
            .background(
                RoundedRectangle(cornerRadius: 36)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: 36)
                            .stroke(Color.white.opacity(0.1), lineWidth: 1)
                    )
                    .shadow(color: .black.opacity(0.25), radius: 25, x: 0, y: 15)
            )
            .frame(width: 400)
        }
        .onAppear {
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { granted, _ in
                if granted {
                    print("Notifications allowed")
                }
            }
            Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { _ in
                updateBatteryInfo()
            }
        }
    }

    func infoCard(icon: String, label: String, value: String, color: Color = .white) -> some View {
        HStack {
            Label(label, systemImage: icon)
                .foregroundColor(.white.opacity(0.8))
                .font(.headline)
                .frame(width: 130, alignment: .leading)

            Spacer()

            Text(value)
                .foregroundColor(color)
                .font(.headline)
                .fontWeight(.medium)
        }
        .padding(.horizontal)
        .padding(.vertical, 10)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(Color.white.opacity(0.08))
                .background(.ultraThinMaterial)
                .shadow(color: .black.opacity(0.2), radius: 8, x: 0, y: 4)
        )
    }

    func updateBatteryInfo() {
        batteryPercentage = getBatteryPercentage()
        isCharging = getChargingStatus()
        condition = getBatteryCondition()
        lastChecked = formattedTime()

        if batteryPercentage >= 80, !notificationSentHigh {
            sendNotification(title: "Battery Alert", message: "Battery is above 80%. Consider unplugging.")
            notificationSentHigh = true
        } else if batteryPercentage < 80 {
            notificationSentHigh = false
        }

        if batteryPercentage <= 30, !notificationSentLow {
            sendNotification(title: "Battery Alert", message: "Battery is below 30%. Consider charging.")
            notificationSentLow = true
        } else if batteryPercentage > 30 {
            notificationSentLow = false
        }

        if batteryPercentage > 80 && isCharging {
            stopCharging()
        } else if batteryPercentage < 30 && !isCharging {
            startCharging()
        }
    }

    func sendNotification(title: String, message: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = message
        content.sound = .default

        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request)
    }

    func getBatteryPercentage() -> Int {
        let task = Process()
        task.launchPath = "/usr/bin/pmset"
        task.arguments = ["-g", "batt"]
        let pipe = Pipe()
        task.standardOutput = pipe
        task.launch()

        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        task.waitUntilExit()

        if let output = String(data: data, encoding: .utf8),
           let range = output.range(of: #"(\d{1,3})%"#, options: .regularExpression) {
            let percentStr = String(output[range]).replacingOccurrences(of: "%", with: "")
            return Int(percentStr) ?? 100
        }
        return 100
    }

    func getChargingStatus() -> Bool {
        let task = Process()
        task.launchPath = "/usr/bin/pmset"
        task.arguments = ["-g", "batt"]
        let pipe = Pipe()
        task.standardOutput = pipe
        task.launch()

        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        task.waitUntilExit()

        guard let output = String(data: data, encoding: .utf8) else { return false }
        return output.contains("AC Power") || output.contains("charging")
    }

    func getBatteryCondition() -> String {
        let task = Process()
        task.launchPath = "/usr/sbin/system_profiler"
        task.arguments = ["SPPowerDataType"]
        let pipe = Pipe()
        task.standardOutput = pipe
        task.launch()

        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        task.waitUntilExit()

        guard let output = String(data: data, encoding: .utf8) else { return "Unknown" }

        if let range = output.range(of: #"Condition:\s+(Normal|Replace Soon|Service Battery|Poor)"#, options: .regularExpression) {
            let matched = String(output[range])
            return matched.components(separatedBy: ": ").last ?? "Unknown"
        }

        return "Unknown"
    }

    func formattedTime() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "h:mm:ss a"
        return formatter.string(from: Date())
    }

    func conditionColor() -> Color {
        switch condition {
        case "Normal": return .green
        case "Replace Soon": return .orange
        case "Service Battery", "Poor": return .red
        default: return .gray
        }
    }

    func stopCharging() {
        print("Simulated stop charging")
    }

    func startCharging() {
        print("Simulated start charging")
    }
}
