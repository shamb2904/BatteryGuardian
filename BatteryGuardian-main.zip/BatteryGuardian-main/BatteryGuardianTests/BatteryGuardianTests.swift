//
//  BatteryGuardianTests.swift
//  BatteryGuardianTests
//
//  Created by Agam Raj Singh on 13/06/25.
//

import Testing
@testable import BatteryGuardian

struct BatteryGuardianTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
