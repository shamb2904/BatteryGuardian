import SwiftUI
import LaunchAtLogin

@main
struct BatteryGuardianApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    init() {
        LaunchAtLogin.isEnabled = true
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

