import Cocoa
import SwiftUI

class AppDelegate: NSObject, NSApplicationDelegate {
    var statusItem: NSStatusItem!
    var popover: NSPopover!
    var timer: Timer?

    func applicationDidFinishLaunching(_ notification: Notification) {
        let contentView = ContentView()

        popover = NSPopover()
        popover.contentSize = NSSize(width: 300, height: 400)
        popover.behavior = .transient
        popover.contentViewController = NSHostingController(rootView: contentView)

        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)

        if let button = statusItem.button {
            button.image = NSImage(systemSymbolName: "battery.100", accessibilityDescription: "Battery Guardian")
            button.action = #selector(togglePopover(_:))
        }

        // Start updating the battery icon dynamically
        startBatteryIconUpdater()
    }

    @objc func togglePopover(_ sender: AnyObject?) {
        if let button = statusItem.button {
            if popover.isShown {
                popover.performClose(sender)
            } else {
                popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
                popover.contentViewController?.view.window?.becomeKey()
            }
        }
    }

    func startBatteryIconUpdater() {
        timer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { _ in
            let percent = self.getBatteryPercentage()
            var symbolName = "battery.100"

            switch percent {
            case 0..<20:
                symbolName = "flame.fill"                  // Danger Zone 🔥
            case 20..<60:
                symbolName = "bolt.fill"                   // Mid Power ⚡
            case 60..<90:
                symbolName = "atom"                        // Stable ⚛️
            default:
                symbolName = "brain.head.profile"          // Fully Charged 🧠
            }

            DispatchQueue.main.async {
                self.statusItem.button?.image = NSImage(systemSymbolName: symbolName, accessibilityDescription: "Battery Level: \(percent)%")
            }
        }

        timer?.fire() // Run immediately at launch
    }

    func getBatteryPercentage() -> Int {
        let task = Process()
        task.launchPath = "/usr/bin/pmset"
        task.arguments = ["-g", "batt"]

        let pipe = Pipe()
        task.standardOutput = pipe
        task.launch()

        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        task.waitUntilExit()

        if let output = String(data: data, encoding: .utf8),
           let percentRange = output.range(of: #"(\d{1,3})%"#, options: .regularExpression) {
            let percentString = String(output[percentRange]).replacingOccurrences(of: "%", with: "")
            return Int(percentString) ?? 100
        }

        return 100
    }
}
