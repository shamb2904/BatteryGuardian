# 🔋 BatteryGuardian 🛡️  
A sleek macOS app to monitor and protect your MacBook’s battery health using SwiftUI.

---

## 🚀 Features

- 🔋 Real-time battery % & condition
- ⚡ Alerts when battery <30% or >80%
- 🧠 Uses `system_profiler` for accurate data
- 🔔 Background notifications
- 🎨 SwiftUI dynamic interface

---

## 🛠 Built With

- SwiftUI
- Xcode 15+
- macOS Sequoia
- System CLI tools

---

---

## 📦 How to Run

```bash
git clone https://github.com/agmarajthakur/BatteryGuardian.git
cd BatteryGuardian
open BatteryGuardian.xcodeproj
